﻿namespace Lab4_23.Models.DTOs
{
    public class CamionDTO
    {
        public Guid Id { get; set; }
        public string Name_truck { get; set; }

        public string Color { get; set; }

        public int KmNumber { get; set; }
    }
}
