﻿namespace Lab4_23.Models.DTOs
{
    public class Model1DTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
