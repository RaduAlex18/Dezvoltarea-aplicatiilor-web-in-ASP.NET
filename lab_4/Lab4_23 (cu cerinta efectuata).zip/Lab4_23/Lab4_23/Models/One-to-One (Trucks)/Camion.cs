﻿using Lab4_23.Models.Base;

namespace Lab4_23.Models.One_to_One
{
    public class Camion : BaseEntity
    {
        public string? Name_truck { get; set; }

        public string? Color { get; set; }

        public int KmNumber { get; set; }

        // relation
        public Cursa Cursa { get; set; }
    }
}
