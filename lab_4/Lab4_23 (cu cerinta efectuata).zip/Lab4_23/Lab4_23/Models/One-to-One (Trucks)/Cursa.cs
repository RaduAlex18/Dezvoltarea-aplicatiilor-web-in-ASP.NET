﻿using Lab4_23.Models.Base;

namespace Lab4_23.Models.One_to_One
{
    public class Cursa : BaseEntity
    {
        public string? Cargo { get; set; }

        public string? Destination { get; set; }

        public int KmTransport { get; set; }

        // relations
        public Camion Camion { get; set; }
        public Guid CamionId { get; set; }
    }
}
