﻿using Lab4_23.Models.Base;

namespace Lab4_23.Models
{
    public class Truck : BaseEntity
    {
        public string? Truck_name { get; set; }
        public string? Color { get; set; }
        public int Year { get; set; }
        public int Km { get; set; }
    }
}
